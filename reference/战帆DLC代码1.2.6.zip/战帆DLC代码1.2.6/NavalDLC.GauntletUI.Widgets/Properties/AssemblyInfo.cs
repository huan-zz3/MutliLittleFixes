﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyCompany("NavalDLC.GauntletUI.Widgets")]
[assembly: AssemblyConfiguration("Shipping_Client")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("NavalDLC.GauntletUI.Widgets")]
[assembly: AssemblyTitle("NavalDLC.GauntletUI.Widgets")]
