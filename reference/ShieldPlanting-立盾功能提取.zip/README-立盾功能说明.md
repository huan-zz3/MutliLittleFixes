# 立盾功能（Shield Planting）独立代码提取说明

本目录提取自 `MutliLittleFixes` 主 Mod 中「盾牌插地（立盾）」功能所依赖的全部源码文件，
方便单独审阅、移植或对比参考。

## 提取的文件清单

| 文件 | 作用 | 必/选 |
|------|------|-------|
| `ShieldPlantingBehavior.cs` | 立盾核心逻辑（MissionLogic）：玩家 F11 插盾 / J 收盾，命令驱动自动插收盾，插地盾血量管理，海战禁用 | 必须 |
| `PlantedShieldComponent.cs` | 插地盾血量组件（MissionObject），挂在插地盾实体上接收原版伤害、扣血、归零销毁 | 必须 |
| `NavalBattleDetector.cs` | 海战检测工具（战帆 DLC 海战/沿海掠夺海战），立盾在海战中显式禁用 | 必须 |
| `Settings.cs` | MCM 设置类，立盾功能使用其中 `ShieldPlanting*` 开关（约 7 个）+ 调试开关 | 必须（仅需其中的 ShieldPlanting 部分） |

> 注：`Settings.cs` 为整个主 Mod 的设置类。立盾功能实际只读取以下属性（可直接裁剪保留）：
> `ShieldPlantingEnabled`、`ShieldPlantingAutoDeployEnabled`、`ShieldPlantingMaxAutoDeployPerScan`、
> `ShieldPlantingAiEnabled`、`ShieldPlantingShieldHpEnabled`、`ShieldPlantingShieldHpPercent`、
> `ShieldPlantingDebugLog`，以及分组名 `mlf_group_shield_planting` / `mlf_group_debug`。

## 依赖说明

- `ShieldPlantingBehavior` 提供 `IsDeployed(Agent)` 公共方法，供站位重排
  `ShieldBearerFormationBehavior` 查询（已插盾士兵不参与重排）。**立盾本身不依赖站位重排**，
  仅站位重排反向依赖它，故立盾可独立工作。
- `PlantedShieldComponent` 通过 `CreateAndAddScriptComponent` 动态挂载，无需 prefab
  （v1.5.0 起改为用士兵盾牌的 `MissionWeapon` 动态生成实体，`Prefabs/PlantedShield.xml` 已不再被使用）。
- 海战禁用：`ShieldPlantingBehavior.OnMissionTick` 内调用 `NavalBattleDetector.IsNavalBattle(Mission)`。

## 语言词条（`{=mlf_shield_*}` 等）

玩家可见文本使用游戏原生本地化 `{=ID}` 形式，词条分散在主 Mod 的
`ModuleData/Languages/English/std_module_strings.xml` 与
`ModuleData/Languages/CNs/std_module_strings_zho-CN.xml` 中。本功能涉及词条：

- `mlf_shield_enabled` / `mlf_shield_enabled_hint`
- `mlf_shield_auto_deploy` / `mlf_shield_auto_deploy_hint`
- `mlf_shield_max_per_scan` / `mlf_shield_max_per_scan_hint`
- `mlf_shield_none_found` / `mlf_shield_deployed` / `mlf_shield_none_deployed` / `mlf_shield_undeployed` / `mlf_shield_destroyed`
- `mlf_shield_ai_enabled` / `mlf_shield_ai_enabled_hint`
- `mlf_shield_hp_enabled` / `mlf_shield_hp_enabled_hint`
- `mlf_shield_hp_percent` / `mlf_shield_hp_percent_hint`
- `mlf_group_shield_planting` / `mlf_group_debug`

## 与原版 PaviseShield 的对比提升

详见本目录 `对比-PaviseShield.md`。核心差异：PaviseShield 只支持单一固定盾型
（写死 `pavise_shield` 物品与一个硬编码 prefab），仅玩家侧手动 F11/J、无血量概念；
本立盾功能支持任意盾型、命令驱动自动插收盾、对 AI 部队生效、插地盾拥有独立可摧毁血量、
并修复了多种原版问题（弩兵强制握持导致射不出、不同尺寸盾贴地高度等）。
