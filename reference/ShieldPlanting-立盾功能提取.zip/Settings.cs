using MCM.Abstractions.Attributes;
using MCM.Abstractions.Attributes.v2;
using MCM.Abstractions.Base.Global;
using TaleWorlds.Localization;

namespace MutliLittleFixes
{
    /// <summary>
    /// 立盾功能独立设置类（从主 Mod 裁剪，仅保留 ShieldPlanting 相关开关 + 调试开关）。
    /// 若移植回主 Mod，直接复用主 Mod 的 Settings.cs 即可（其中已有同 Id 的完整属性）。
    /// </summary>
    internal sealed class Settings : AttributeGlobalSettings<Settings>
    {
        public override string Id => "MutliLittleFixes_v1";

        public override string DisplayName
        {
            get { return new TextObject("{=mlf_mod_name}Shield Planting", null).ToString(); }
        }

        public override string FolderName => "MutliLittleFixes";
        public override string FormatType => "json2";

        [SettingPropertyBool("{=mlf_debug_shield_auto}Shield Auto Plant Debug Log", Order = 99, RequireRestart = false, HintText = "{=mlf_debug_shield_auto_hint}Display shield auto plant/pick-up debug logs (scan summary, formation order changes, auto plant/pick-up actions, skipped reasons) in the bottom-left corner of the screen")]
        [SettingPropertyGroup("{=mlf_group_debug}Debug")]
        public bool ShieldPlantingDebugLog { get; set; } = false;

        [SettingPropertyBool("{=mlf_shield_enabled}Plant Shields", Order = 0, RequireRestart = false, HintText = "{=mlf_shield_enabled_hint}Any ranged foot soldier carrying a shield (horse archers excluded) can plant their shield into the ground as an obstacle. In battle, press F11 to plant the shields of the selected formation (or all eligible soldiers if no formation is selected), and press J to pick them up. Planted troops keep fighting with their ranged weapons while the planted shield acts as cover. When disabled, all planted shields are picked up and the feature stops")]
        [SettingPropertyGroup("{=mlf_group_shield_planting}Shield Planting & Formation")]
        public bool ShieldPlantingEnabled { get; set; } = true;

        [SettingPropertyBool("{=mlf_shield_auto_deploy}Auto Plant / Pick Up on Orders", Order = 1, RequireRestart = false, HintText = "{=mlf_shield_auto_deploy_hint}Your shield-bearing ranged soldiers automatically plant their shields when they are standing still with a hold/move-to-position order (fully arrived at the target point, not charging/advancing/falling back), and automatically pick them up when they receive a moving combat order (charge, advance, fall back, retreat, follow, attack entity) or are ordered to a new position while planted. Manual F11/J actions always take priority; the auto logic stands down for 3 seconds after a manual action")]
        [SettingPropertyGroup("{=mlf_group_shield_planting}Shield Planting & Formation")]
        public bool ShieldPlantingAutoDeployEnabled { get; set; } = true;

        [SettingPropertyInteger("{=mlf_shield_max_per_scan}Max Auto-Plants per Scan", 1, 50, "0", Order = 2, RequireRestart = false, HintText = "{=mlf_shield_max_per_scan_hint}Maximum number of soldiers that can plant OR pick up their shields in a single auto-scan cycle (every 2 seconds) - planting and picking up are throttled independently, each up to this many per cycle. With many shield-bearing ranged soldiers, this prevents stuttering from many shields being spawned or removed at the same moment; the remaining soldiers are handled on the following cycles. Manual F11/J actions are never limited")]
        [SettingPropertyGroup("{=mlf_group_shield_planting}Shield Planting & Formation")]
        public int ShieldPlantingMaxAutoDeployPerScan { get; set; } = 20;

        [SettingPropertyBool("{=mlf_shield_ai_enabled}Apply to AI Troops", Order = 3, RequireRestart = false, HintText = "{=mlf_shield_ai_enabled_hint}AI-controlled soldiers on all non-player teams (enemy armies and allied AI lords) also plant their shields automatically when holding a position, and shield-bearing ranged soldiers in their line/loose formations are rearranged to the front, flanks and rear, mirroring the player-side behavior. When disabled, only the player's own troops are affected")]
        [SettingPropertyGroup("{=mlf_group_shield_planting}Shield Planting & Formation")]
        public bool ShieldPlantingAiEnabled { get; set; } = false;

        [SettingPropertyBool("{=mlf_shield_hp_enabled}Planted Shield Has Hit Points", Order = 4, RequireRestart = false, HintText = "{=mlf_shield_hp_enabled_hint}Planted shields have their own hit points and are destroyed when they run out. All vanilla damage sources count: arrows, bolts, thrown weapons and melee swings from swords, axes and polearms reduce a planted shield's hit points; at zero the shield disappears and the soldier permanently loses that shield (it is not returned when picking up). When disabled, planted shields act as indestructible obstacles as before. Applies immediately")]
        [SettingPropertyGroup("{=mlf_group_shield_planting}Shield Planting & Formation")]
        public bool ShieldPlantingShieldHpEnabled { get; set; } = true;

        [SettingPropertyFloatingInteger("{=mlf_shield_hp_percent}Planted Shield Hit Points", 0.01f, 2.0f, "0%", Order = 5, RequireRestart = false, HintText = "{=mlf_shield_hp_percent_hint}Hit points of a planted shield as a percentage of the shield's CURRENT hit points at the moment of planting (50% = half of the soldier's remaining shield durability when planting, e.g. a shield with 360/400 durability plants with 180 hit points). The percentage is read in real time each time a shield is planted; shields already on the ground keep their current hit points when this value is changed")]
        [SettingPropertyGroup("{=mlf_group_shield_planting}Shield Planting & Formation")]
        public float ShieldPlantingShieldHpPercent { get; set; } = 0.5f;
    }
}
